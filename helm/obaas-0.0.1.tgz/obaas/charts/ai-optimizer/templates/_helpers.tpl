{{/*
Copyright (c) 2024, 2025, Oracle and/or its affiliates.
Licensed under the Universal Permissive License v1.0 as shown at http://oss.oracle.com/licenses/upl.
spell-checker: ignore trunc ollama
*/}}

{{/* ******************************************
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*********************************************** */}}
{{- define "global.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" | trim }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" | trim }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" | trim }}
{{- end }}
{{- end }}
{{- end }}


{{/* ******************************************
Expand the name of the chart.
*********************************************** */}}
{{- define "global.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" | trim }}
{{- end }}


{{/* ******************************************
Create chart name and version as used by the chart label.
*********************************************** */}}
{{- define "global.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" | trim }}
{{- end }}


{{/* ******************************************
Selector labels
*********************************************** */}}
{{- define "global.selectorLabels" -}}
app.kubernetes.io/name: {{ include "global.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}


{{/* ******************************************
Common labels
*********************************************** */}}
{{- define "global.labels" -}}
helm.sh/chart: {{ include "global.chart" . }}
{{ include "global.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}


{{/* ******************************************
Validate that either global.api.apiKey or global.api.secretName is provided.
*********************************************** */}}
{{- define "global.apiKeyOrSecretName.required" -}}
  {{- $apiKey := .Values.global.api.apiKey | trim | default "" -}}
  {{- $secretName := .Values.global.api.secretName | trim | default "" -}}

  {{- if and (eq $apiKey "") (eq $secretName "") -}}
    {{- fail "You must specify either global.api.apiKey or global.api.secretName" -}}
  {{- end -}}

  {{- if and (ne $apiKey "") (ne $secretName "") -}}
    {{- fail "You cannot specify both global.api.apiKey and global.api.secretName; please choose one" -}}
  {{- end -}}
{{- end -}}

{{/* ******************************************
Define the API Key Secret with Defaults
*********************************************** */}}
{{- define "global.apiSecretName" -}}
{{- .Values.global.api.secretName | default (printf "%s-api-key" .Release.Name) -}}
{{- end }}

{{- define "global.apiSecretKey" -}}
{{- .Values.global.api.secretKey | default "apiKey" -}}
{{- end }}


{{/* ******************************************
Set the path based on baseUrlPath
Always returns a path with leading and trailing slashes for proper concatenation.
*********************************************** */}}
{{- define "global.getPath" -}}
  {{- $baseUrlPath := .Values.global.baseUrlPath | default "" -}}
  {{- if eq $baseUrlPath "" -}}
    /
  {{- else -}}
    {{- $path := $baseUrlPath -}}
    {{- if not (hasPrefix "/" $path) -}}
      {{- $path = printf "/%s" $path -}}
    {{- end -}}
    {{- if not (hasSuffix "/" $path) -}}
      {{- $path = printf "%s/" $path -}}
    {{- end -}}
    {{- $path -}}
  {{- end -}}
{{- end -}}


{{/* ******************************************
Define the serviceName and serviceUrl of the API Server for Client Access.
*********************************************** */}}
{{- define "server.serviceName" -}}
{{ include "global.fullname" . }}-server-8000
{{- end -}}

{{- define "server.serviceUrl" -}}
http://{{ include "server.serviceName" . }}.{{ .Release.Namespace }}.svc.cluster.local
{{- end -}}


{{/* ******************************************
Define serviceName and serviceUrl of the Ollama Server for API Server Access.
*********************************************** */}}
{{- define "ollama.serviceName" -}}
{{ .Release.Name }}-ollama-11434
{{- end -}}

{{- define "ollama.serviceUrl" -}}
http://{{ include "ollama.serviceName" . }}.{{ .Release.Namespace }}.svc.cluster.local:11434
{{- end -}}


{{/* ******************************************
Database Secret Name
*********************************************** */}}
{{- define "server.databaseSecret" -}}
{{- $authN := .Values.server.database.authN | default dict }}
{{- $secretName := $authN.secretName | default "" }}
{{- if $secretName -}}
  {{- $secretName -}}
{{- else -}}
  {{- printf "%s-db-authn" .Release.Name -}}
{{- end -}}
{{- end }}


{{/* ******************************************
Database Privileged Secret Name
*********************************************** */}}
{{- define "server.databasePrivSecret" -}}
{{- $authN := .Values.server.database.privAuthN | default dict }}
{{- $secretName := $authN.secretName | default "" }}
{{- if $secretName -}}
  {{- $secretName -}}
{{- else -}}
  {{- printf "%s-db-priv-authn" .Release.Name -}}
{{- end -}}
{{- end }}


{{/* ******************************************
Environment to include Database Authentication
*********************************************** */}}
{{- define "server.database.authN" -}}
- name: DB_USERNAME
  valueFrom:
    secretKeyRef:
        name: {{ include "server.databaseSecret" . }}
        key: {{ default "username" .Values.server.database.authN.usernameKey }}
- name: DB_PASSWORD
  valueFrom:
    secretKeyRef:
        name: {{ include "server.databaseSecret" . }}
        key: {{ default "password" .Values.server.database.authN.passwordKey }}
- name: DB_DSN
  valueFrom:
    secretKeyRef:
        name: {{ include "server.databaseSecret" . }}
        key: {{ default "service" .Values.server.database.authN.serviceKey }}
{{- end }}


{{/* ******************************************
Create the pull model list for Ollama
*********************************************** */}}
{{- define "ollama.modelPullList" -}}
  {{- if and .Values.ollama.models.enabled .Values.ollama.models.modelPullList }}
    {{- join " " .Values.ollama.models.modelPullList -}}
  {{- else }}
    {{- "" -}}
  {{- end }}
{{- end -}}

{{/* ******************************************
Validate that server.database.other fields are provided when database type is OTHER.
Requires either 'dsn' OR all of (host, port, service_name).
*********************************************** */}}
{{- define "server.database.validateOtherType" -}}
  {{- if .Values.server.database -}}
    {{- $dbType := .Values.server.database.type | default "" -}}

    {{- if eq $dbType "OTHER" -}}
      {{- $dsn := .Values.server.database.other.dsn -}}
      {{- $host := .Values.server.database.other.host -}}
      {{- $port := .Values.server.database.other.port -}}
      {{- $serviceName := .Values.server.database.other.service_name -}}

      {{- /* Check if dsn is provided and not empty */ -}}
      {{- $hasDsn := false -}}
      {{- if $dsn -}}
        {{- if and (kindIs "string" $dsn) (ne ($dsn | trim) "") -}}
          {{- $hasDsn = true -}}
        {{- end -}}
      {{- end -}}

      {{- /* Check if individual fields are provided */ -}}
      {{- $hasHost := false -}}
      {{- if $host -}}
        {{- if or (not (kindIs "string" $host)) (ne ($host | trim) "") -}}
          {{- $hasHost = true -}}
        {{- end -}}
      {{- end -}}

      {{- $hasPort := false -}}
      {{- if $port -}}
        {{- if or (not (kindIs "string" $port)) (ne ($port | trim) "") -}}
          {{- $hasPort = true -}}
        {{- end -}}
      {{- end -}}

      {{- $hasServiceName := false -}}
      {{- if $serviceName -}}
        {{- if or (not (kindIs "string" $serviceName)) (ne ($serviceName | trim) "") -}}
          {{- $hasServiceName = true -}}
        {{- end -}}
      {{- end -}}

      {{- /* Validate: must have either dsn OR all three individual fields */ -}}
      {{- if not $hasDsn -}}
        {{- if not (and $hasHost $hasPort $hasServiceName) -}}
          {{- fail "server.database.type is OTHER: must provide either 'dsn' OR all of (host, port, service_name)" -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{/* ******************************************
Validate that if server.oci_config.configMapName is specified,
then none of the other OCI config values (tenancy, user, fingerprint, region) should be provided.
*********************************************** */}}
{{- define "server.ociConfig.validate" -}}
  {{- if .Values.server.oci_config -}}
    {{- $configMapName := .Values.server.oci_config.configMapName | trim | default "" -}}
    {{- $tenancy := .Values.server.oci_config.tenancy | trim | default "" -}}
    {{- $user := .Values.server.oci_config.user | trim | default "" -}}
    {{- $fingerprint := .Values.server.oci_config.fingerprint | trim | default "" -}}
    {{- $region := .Values.server.oci_config.region | trim | default "" -}}

    {{- /* If configMapName is provided, ensure no other config values are provided */ -}}
    {{- if ne $configMapName "" -}}
      {{- if or (ne $tenancy "") (ne $user "") (ne $fingerprint "") (ne $region "") -}}
        {{- fail "server.oci_config.configMapName is specified: you cannot also provide tenancy, user, fingerprint, or region. Either provide configMapName to reference an existing ConfigMap, OR provide the config values to create a new ConfigMap." -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}


{{/* ******************************************
ADB-S Secret Name Helpers
These helpers return the secret names for ADB-S wallet/tns-admin,
supporting either existing secrets or auto-generated ones.
*********************************************** */}}
{{- define "server.database.useExistingAdbSecrets" -}}
{{- $adb := .Values.server.database.adb | default dict -}}
{{- default false $adb.useExisting -}}
{{- end -}}

{{- define "server.database.adbTnsAdminSecret" -}}
{{- $adb := .Values.server.database.adb | default dict -}}
{{- $tnsAdmin := $adb.tnsAdminSecretName | default "" -}}
{{- if ne $tnsAdmin "" -}}
  {{- $tnsAdmin -}}
{{- else -}}
  {{- printf "%s-adb-tns-admin-%d" .Release.Name .Release.Revision -}}
{{- end -}}
{{- end -}}

{{- define "server.database.adbWalletPassSecret" -}}
{{- $adb := .Values.server.database.adb | default dict -}}
{{- $walletPass := $adb.walletPassSecretName | default "" -}}
{{- if ne $walletPass "" -}}
  {{- $walletPass -}}
{{- else -}}
  {{- printf "%s-adb-wallet-pass-%d" .Release.Name .Release.Revision -}}
{{- end -}}
{{- end -}}

{{- define "server.database.adbWalletPassSecretKey" -}}
{{- $adb := .Values.server.database.adb | default dict -}}
{{- $walletPassKey := $adb.walletPassSecretKey | default "" -}}
{{- if ne $walletPassKey "" -}}
  {{- $walletPassKey -}}
{{- else -}}
  {{- include "server.database.adbWalletPassSecret" . -}}
{{- end -}}
{{- end -}}


{{/* ******************************************
Database Type Helpers
These helpers provide consistent database type checking across templates.
*********************************************** */}}
{{- define "server.database.type" -}}
{{- if .Values.server.database -}}
  {{- .Values.server.database.type -}}
{{- end -}}
{{- end -}}

{{- define "server.database.isSIDB" -}}
{{- eq (include "server.database.type" .) "SIDB-FREE" -}}
{{- end -}}

{{- define "server.database.isADBFree" -}}
{{- eq (include "server.database.type" .) "ADB-FREE" -}}
{{- end -}}

{{- define "server.database.isADBS" -}}
{{- eq (include "server.database.type" .) "ADB-S" -}}
{{- end -}}

{{- define "server.database.isOther" -}}
{{- eq (include "server.database.type" .) "OTHER" -}}
{{- end -}}

{{- define "server.database.isADB" -}}
{{- or (eq (include "server.database.type" .) "ADB-S") (eq (include "server.database.type" .) "ADB-FREE") -}}
{{- end -}}

{{- define "server.database.isContainerDB" -}}
{{- or (eq (include "server.database.type" .) "SIDB-FREE") (eq (include "server.database.type" .) "ADB-FREE") -}}
{{- end -}}

{{- define "server.database.needsPrivAuth" -}}
{{- or (eq (include "server.database.isADB" .) "true") (eq (include "server.database.isOther" .) "true") -}}
{{- end -}}

{{/* ******************************************
Database Service Name Helper
Returns the short database type prefix (sidb or adb) for service naming.
*********************************************** */}}
{{- define "server.database.dbName" -}}
{{- $dbType := include "server.database.type" . -}}
{{- if $dbType -}}
  {{- lower (split "-" $dbType)._0 -}}
{{- end -}}
{{- end -}}


{{/* ******************************************
Password Generator for Databases
*********************************************** */}}
{{- define "server.randomPassword" -}}
  {{- $minLen := 12 -}}
  {{- $maxLen := 30 -}}
  {{- $one := int 1 -}}
  {{- $two := int 2 -}}

  {{- /* Random length between min and max */ -}}
  {{- $range := int (add (sub $maxLen $minLen) 1) -}}
  {{- $randOffset := int (randInt 0 $range) -}}
  {{- $length := add $minLen $randOffset -}}

  {{- /* Required characters */ -}}
  {{- $upper := randAlphaNum $one | upper -}}
  {{- $lower := randAlphaNum $one | lower -}}
  {{- $digit := randNumeric $one -}}
  {{- $start := randAlpha $one | lower -}}

  {{- /* Special character, one of "-" or "_" */ -}}
  {{- $specialChars := list "-" "_" -}}
  {{- $specialIndex := int (randInt 0 $two) -}}
  {{- $special := index $specialChars $specialIndex -}}

  {{- /* Remaining characters to reach desired length */ -}}
  {{- $restLength := int (sub $length 5) -}}
  {{- $rest := randAlphaNum $restLength -}}

  {{- /* Final password */ -}}
  {{- $password := printf "%s%s%s%s%s%s" $start $special $upper $lower $digit $rest -}}
  {{- $password -}}
{{- end }}